import React from 'react'

const Footer = () => {
  return (
    <div>
        <h1>Practice Projrct</h1>
    </div>
  )
}

export default Footer