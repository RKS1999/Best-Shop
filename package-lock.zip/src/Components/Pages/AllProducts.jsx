import React, { useEffect, useState } from "react";
// import axios from "axios";
import { useNavigate } from "react-router-dom";
import { addProduct } from "../../Features/Slice/CartSlice";
import { useDispatch } from "react-redux";

const baseURL = "https://fakestoreapi.com/products";
const AllProducts = (searchQuery) => {
  const [items, setItems] = useState([]);
  const [filterItem, setFilterItem] = useState([]);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const fetchData = async () => {
    // const { data } = await axios.get(baseURL);
    const responce = await fetch(baseURL);
    const result = await responce.json();
    // setItems(result);
    return result;
    // console.log(data);
    // setItem(data);
  };

  useEffect(() => {
    // fetchData();
    fetchData().then((result) => {
      setItems(result);
      setFilterItem(result);
    });
  }, []);

  const filterProduct = (category) => {
    if (category === "allproducts") {
      setFilterItem(items);
    } else {
      const updatedProducts = items.filter(
        (item) => item.category === category
      );
      setFilterItem(updatedProducts);
    }
  };

  const limitTitle = (title, limit = 15) => {
    if (title.length > limit) {
      return title.substring(0, limit) + "...";
    }
    return title;
  };

  return (
    <div className="row" style={{ margin: "10px" }}>
      <h1>Shop</h1>

      <div className="filter-btns" style={{ margin: "5px", padding: "5px" }}>
        <button
          onClick={() => filterProduct("allproducts")}
          style={{
            background: "transparent",
            border: "transparent",
            color: "blue",
          }}
        >
          All Product
        </button>
        <button
          onClick={() => filterProduct("men's clothing")}
          style={{
            background: "transparent",
            border: "transparent",
            color: "blue",
          }}
        >
          Men
        </button>
        <button
          onClick={() => filterProduct("women's clothing")}
          style={{
            background: "transparent",
            border: "transparent",
            color: "blue",
          }}
        >
          Women
        </button>
        <button
          onClick={() => filterProduct("jewelery")}
          style={{
            background: "transparent",
            border: "transparent",
            color: "blue",
          }}
        >
          jewelery
        </button>
        <button
          onClick={() => filterProduct("electronics")}
          style={{
            background: "transparent",
            border: "transparent",
            color: "blue",
          }}
        >
          Electronics
        </button>
      </div>
      {filterItem.map((data, index) => (
        <div className="col-md-4 mb-3" key={index}>
          <div className="card">
            <img
              src={data.image}
              className="card-img-top"
              style={{ height: "250px", width: "auto" }}
              alt={data.title}
            />
            <div className="card-body" style={{ borderRadius: "50px" }}>
              <h5 className="card-title">{limitTitle(data.title)}</h5>
              <p className="card-text">Price: ${data.price}</p>
              <p className="card-text">
                <small className="text-body-secondary">
                  Rating: {data.rating.rate}*
                </small>
              </p>
              <div>
                <br />
                <button
                  className="btn btn-primary mr-2"
                  style={{ margin: "2px" }}
                >
                  Buy Now
                </button>
                <button
                  className="btn btn-success"
                  style={{ margin: "2px" }}
                  onClick={() => {
                    dispatch(addProduct(data)), navigate("/cart");
                  }}
                >
                  Add To Cart
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AllProducts;
