import React, { useState, useEffect } from "react";
// import axios from "axios";
import { Link } from "react-router-dom";

const baseURL = "https://fakestoreapi.com/products";
const Home = (searchQuery) => {
  const [items, setItems] = useState([]);
  const [filterItem, setFilterItem] = useState([]);
  const fetchData = async () => {
    // const { data } = await axios.get(baseURL);
    const responce = await fetch(baseURL);
    const result = await responce.json();
    // setItems(result);
    return result;
    // console.log(data);
    // setItem(data);
  };

  useEffect(() => {
    // fetchData();
    fetchData().then((result) => {
      setItems(result);
      setFilterItem(result);
    });
  }, []);

  const filterProduct = (category) => {
    if (category === "allproducts") {
      setFilterItem(items);
    } else {
      const updatedProducts = items.filter(
        (item) => item.category === category
      );
      setFilterItem(updatedProducts);
    }
  };

  const limitTitle = (title, limit = 10) => {
    if (title.length > limit) {
      return title.substring(0, limit) + "...";
    }
    return title;
  };

  return (
    <div>
      <div class="container-fluid">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <h1>Home</h1>
          </div>
        </div>
      </div>
      <div className="container h-100">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div style={{ paddingTop: "5px" }}>
            <div className="row">
              {/* Accordion Start */}
              <div
                className="col-2"
                style={{
                  border: "1px solid",
                  borderRadius: "10px",
                  height: "600px",
                }}
              >
                <div className="mb-3">
                  <div
                    style={{
                      margin: "10px",
                      display: "flex",
                      flexWrap: "wrap",
                      justifyContent: "left",
                      alignItems: "left",
                    }}
                  >
                    <div className="filter-btns">
                      <button
                        onClick={() => filterProduct("allproducts")}
                        style={{
                          background: "transparent",
                          border: "transparent",
                          color: "blue",
                        }}
                      >
                        All Products
                      </button>
                      <br />
                      <button
                        onClick={() => filterProduct("men's clothing")}
                        style={{
                          background: "transparent",
                          border: "transparent",
                          color: "blue",
                        }}
                      >
                        Men
                      </button>
                      <br />
                      <button
                        onClick={() => filterProduct("women's clothing")}
                        style={{
                          background: "transparent",
                          border: "transparent",
                          color: "blue",
                        }}
                      >
                        Women
                      </button>
                      <br />
                      <button
                        onClick={() => filterProduct("jewelery")}
                        style={{
                          background: "transparent",
                          border: "transparent",
                          color: "blue",
                        }}
                      >
                        jewelery
                      </button>
                      <br />
                      <button
                        onClick={() => filterProduct("electronics")}
                        style={{
                          background: "transparent",
                          border: "transparent",
                          color: "blue",
                        }}
                      >
                        Electronics
                      </button>
                    </div>
                    {/* Add Accordian list here */}
                  </div>
                </div>
              </div>
              {/* Accordion End */}
              <div className="col-10">
                <div className="row" style={{ margin: "10px" }}>
                  {filterItem.map((data, index) => (
                    <div className="col-md-4 mb-3" key={index}>
                      <div className="card">
                        <img
                          src={data.image}
                          className="card-img-top"
                          style={{ height: "250px", width: "auto" }}
                          alt={data.title}
                        />
                        <div
                          className="card-body"
                          style={{ borderRadius: "50px" }}
                        >
                          <h5 className="card-title">
                            {limitTitle(data.title)}
                          </h5>
                          <p className="card-text">Price: ${data.price}</p>
                          <p className="card-text">
                            <small className="text-body-secondary">
                              Rating: {data.rating.rate}*
                            </small>
                          </p>
                          <Link
                            to="allproducts"
                            style={{
                              paddingTop: "10px",
                              color: "blue",
                              textDecoration: "none",
                            }}
                          >
                            Know More
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
