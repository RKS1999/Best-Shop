import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  cartData: [],
};

export const CartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addProduct(state,action){
        const existProductInCart=state.cartData.some((product) =>product.id ===action.payload.id)
        // console.log(existProductInCart);

        if(existProductInCart){
            const updateCartProduct=state.cartData.map((product) =>{
                // console.log(product);
           return product.id === action.payload.id ? {...product,qty:product.qty+1}:product              
        })
        console.log(updateCartProduct);
       return {
        ...state,
        cartData:updateCartProduct
       }
    }else{
      
        return {
            cartData:[...state.cartData,{...action.payload,qty:1}]
        }
      } 
    },
    deleteProduct(){},
    increment(){},
    decrement(){}
  },
});

export const {addProduct,deleteProduct,increment,decrement  } = CartSlice.actions;

//{ type:"counter/imcrement"}

export default CartSlice.reducer;
